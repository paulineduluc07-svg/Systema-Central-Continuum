/*
 * Design: Command Center — Dark operational dashboard
 * Layout: Hero banner + horizontal category tabs + search bar + prompt grid
 * Colors: Dark anthracite bg, amber actions, steel secondary
 * Typography: Instrument Sans (UI), JetBrains Mono (prompts)
 */
import { useState, useMemo } from "react";
import { Search, Zap, Compass, BookOpen, Rocket, Layers, X, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import PromptCard from "@/components/PromptCard";
import { prompts, categories } from "@/lib/prompts";

const iconMap: Record<string, React.ElementType> = {
  Zap,
  Compass,
  BookOpen,
  Rocket,
  Layers,
};

export default function Home() {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredPrompts = useMemo(() => {
    let result = prompts;
    if (activeCategory) {
      result = result.filter((p) => p.category === activeCategory);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.prompt.toLowerCase().includes(q)
      );
    }
    return result;
  }, [activeCategory, searchQuery]);

  const activeCategoryData = categories.find((c) => c.id === activeCategory);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-30"
          style={{
            backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663280949099/UsaNEuiJ3CuHmSfQHWpq33/hero-banner-eKRVFbAvQTsBD9CYXz5SGx.webp)`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background" />

        <div className="relative container pt-12 pb-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Terminal className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground tracking-tight">
                Prompt-OS
              </h1>
              <p className="text-xs text-muted-foreground">
                Votre centre de commande personnel
              </p>
            </div>
          </div>

          <p className="text-sm text-foreground/70 max-w-xl leading-relaxed mb-6">
            {prompts.length} prompts extraits, traduits et classés. Personnalisez les variables, copiez en un clic, et passez à l'action.
          </p>

          {/* Search Bar */}
          <div className="relative max-w-lg">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Rechercher un prompt..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-10 py-2.5 bg-card border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/50 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container">
          <div className="flex items-center gap-1 py-2 overflow-x-auto scrollbar-none">
            <Button
              variant={activeCategory === null ? "default" : "ghost"}
              size="sm"
              onClick={() => setActiveCategory(null)}
              className={`shrink-0 text-xs h-8 ${
                activeCategory === null
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Tous
              <span className="ml-1.5 text-[10px] opacity-70">
                {prompts.length}
              </span>
            </Button>

            {categories.map((cat) => {
              const Icon = iconMap[cat.icon];
              const isActive = activeCategory === cat.id;
              return (
                <Button
                  key={cat.id}
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setActiveCategory(isActive ? null : cat.id)}
                  className={`shrink-0 text-xs h-8 gap-1.5 ${
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {Icon && <Icon className="h-3.5 w-3.5" />}
                  <span className="hidden sm:inline">{cat.title}</span>
                  <span className="sm:hidden">{cat.title.split(" ")[0]}</span>
                  <span className="text-[10px] opacity-70">{cat.count}</span>
                </Button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-6">
        {/* Active Category Header */}
        <AnimatePresence mode="wait">
          {activeCategoryData && (
            <motion.div
              key={activeCategoryData.id}
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="flex items-center gap-3 mb-5"
            >
              {activeCategoryData.image && (
                <img
                  src={activeCategoryData.image}
                  alt=""
                  className="w-10 h-10 rounded-lg object-cover"
                />
              )}
              <div>
                <h2 className={`text-lg font-bold ${activeCategoryData.color}`}>
                  {activeCategoryData.title}
                </h2>
                <p className="text-xs text-muted-foreground">
                  {activeCategoryData.count} prompts disponibles
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Results count */}
        {searchQuery && (
          <p className="text-xs text-muted-foreground mb-4">
            {filteredPrompts.length} résultat{filteredPrompts.length !== 1 ? "s" : ""} pour "{searchQuery}"
          </p>
        )}

        {/* Prompt Grid */}
        {filteredPrompts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {filteredPrompts.map((prompt) => {
              const cat = categories.find((c) => c.id === prompt.category);
              return (
                <PromptCard
                  key={prompt.id}
                  prompt={prompt}
                  categoryColor={cat?.color || "text-gray-400"}
                />
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Search className="h-10 w-10 text-muted-foreground/30 mb-3" />
            <p className="text-sm text-muted-foreground">
              Aucun prompt trouvé.
            </p>
            <p className="text-xs text-muted-foreground/60 mt-1">
              Essayez un autre terme de recherche ou changez de catégorie.
            </p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="border-t border-border mt-12">
        <div className="container py-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="h-4 w-4 text-primary/60" />
            <span className="text-xs text-muted-foreground">
              Prompt-OS v1.0
            </span>
          </div>
          <span className="text-xs text-muted-foreground/50">
            {prompts.length} prompts &middot; {categories.length} catégories
          </span>
        </div>
      </div>
    </div>
  );
}
