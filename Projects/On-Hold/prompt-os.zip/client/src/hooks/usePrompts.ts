import { useState, useEffect, useCallback } from "react";
import { prompts as defaultPrompts, categories as defaultCategories, type Prompt, type Category } from "@/lib/prompts";

const STORAGE_KEY = "prompt-os-custom-prompts";
const DELETED_KEY = "prompt-os-deleted-prompts";
const EDITED_KEY = "prompt-os-edited-prompts";

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function saveToStorage<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

export function usePrompts() {
  const [customPrompts, setCustomPrompts] = useState<Prompt[]>(() =>
    loadFromStorage<Prompt[]>(STORAGE_KEY, [])
  );
  const [deletedIds, setDeletedIds] = useState<string[]>(() =>
    loadFromStorage<string[]>(DELETED_KEY, [])
  );
  const [editedPrompts, setEditedPrompts] = useState<Record<string, Prompt>>(() =>
    loadFromStorage<Record<string, Prompt>>(EDITED_KEY, {})
  );

  // Persist to localStorage
  useEffect(() => {
    saveToStorage(STORAGE_KEY, customPrompts);
  }, [customPrompts]);

  useEffect(() => {
    saveToStorage(DELETED_KEY, deletedIds);
  }, [deletedIds]);

  useEffect(() => {
    saveToStorage(EDITED_KEY, editedPrompts);
  }, [editedPrompts]);

  // Merge default + custom, apply edits, remove deleted
  const allPrompts: Prompt[] = [
    ...defaultPrompts
      .filter((p) => !deletedIds.includes(p.id))
      .map((p) => editedPrompts[p.id] || p),
    ...customPrompts.filter((p) => !deletedIds.includes(p.id)),
  ];

  // Recalculate category counts dynamically
  const allCategories: Category[] = defaultCategories.map((cat) => ({
    ...cat,
    count: allPrompts.filter((p) => p.category === cat.id).length,
  }));

  const addPrompt = useCallback((prompt: Prompt) => {
    setCustomPrompts((prev) => [...prev, prompt]);
  }, []);

  const updatePrompt = useCallback((prompt: Prompt) => {
    // Check if it's a custom prompt
    const isCustom = customPrompts.some((p) => p.id === prompt.id);
    if (isCustom) {
      setCustomPrompts((prev) =>
        prev.map((p) => (p.id === prompt.id ? prompt : p))
      );
    } else {
      // It's a default prompt — store edit overlay
      setEditedPrompts((prev) => ({ ...prev, [prompt.id]: prompt }));
    }
  }, [customPrompts]);

  const deletePrompt = useCallback((id: string) => {
    const isCustom = customPrompts.some((p) => p.id === id);
    if (isCustom) {
      setCustomPrompts((prev) => prev.filter((p) => p.id !== id));
    } else {
      setDeletedIds((prev) => [...prev, id]);
    }
  }, [customPrompts]);

  const isCustom = useCallback(
    (id: string) => customPrompts.some((p) => p.id === id),
    [customPrompts]
  );

  const isEdited = useCallback(
    (id: string) => id in editedPrompts,
    [editedPrompts]
  );

  const resetPrompt = useCallback((id: string) => {
    setEditedPrompts((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    setDeletedIds((prev) => prev.filter((d) => d !== id));
  }, []);

  return {
    prompts: allPrompts,
    categories: allCategories,
    addPrompt,
    updatePrompt,
    deletePrompt,
    isCustom,
    isEdited,
    resetPrompt,
  };
}
