/*
 * Design: Command Center — Dark operational dashboard
 * Card style: Dark card with subtle border, amber accent on actions
 * Font: JetBrains Mono for prompt content, Instrument Sans for UI
 */
import { useState, useCallback } from "react";
import { Copy, Check, ChevronDown, ChevronUp, Pencil, SquarePen, Trash2, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import type { Prompt } from "@/lib/prompts";
import { motion, AnimatePresence } from "framer-motion";

interface PromptCardProps {
  prompt: Prompt;
  categoryColor: string;
  isCustom?: boolean;
  isEdited?: boolean;
  onEdit?: (prompt: Prompt) => void;
  onDelete?: (id: string) => void;
  onReset?: (id: string) => void;
}

export default function PromptCard({
  prompt,
  categoryColor,
  isCustom,
  isEdited,
  onEdit,
  onDelete,
  onReset,
}: PromptCardProps) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const [variables, setVariables] = useState<Record<string, string>>({});

  const getFilledPrompt = useCallback(() => {
    let filled = prompt.prompt;
    for (const v of prompt.variables) {
      const value = variables[v.key] || `[${v.key}]`;
      filled = filled.replaceAll(`[${v.key}]`, value);
    }
    return filled;
  }, [prompt, variables]);

  const handleCopy = useCallback(async () => {
    const text = getFilledPrompt();
    await navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success("Prompt copié !");
    setTimeout(() => setCopied(false), 2000);
  }, [getFilledPrompt]);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="group bg-card border border-border rounded-lg overflow-hidden hover:border-primary/40 transition-all duration-300"
    >
      {/* Header */}
      <div
        className="flex items-start justify-between p-4 cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <div className={`w-2 h-2 rounded-full shrink-0 ${categoryColor.replace("text-", "bg-")}`} />
            <h3 className="font-semibold text-foreground text-sm truncate">
              {prompt.title}
            </h3>
            {isCustom && (
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-primary/15 text-primary font-medium uppercase tracking-wider">
                Perso
              </span>
            )}
            {isEdited && !isCustom && (
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-400 font-medium uppercase tracking-wider">
                Modifié
              </span>
            )}
          </div>
          <p className="text-muted-foreground text-xs leading-relaxed line-clamp-2">
            {prompt.description}
          </p>
        </div>
        <div className="flex items-center gap-1 ml-3 shrink-0">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:text-primary"
            onClick={(e) => {
              e.stopPropagation();
              handleCopy();
            }}
          >
            {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
          </Button>
          {expanded ? (
            <ChevronUp className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
      </div>

      {/* Expanded Content */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            {/* Variables */}
            {prompt.variables.length > 0 && (
              <div className="px-4 pb-3 space-y-2">
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1">
                  <Pencil className="h-3 w-3" />
                  <span>Personnalisez les variables :</span>
                </div>
                {prompt.variables.map((v) => (
                  <div key={v.key} className="flex flex-col gap-1">
                    <label className="text-xs font-medium text-foreground/70">
                      {v.label}
                    </label>
                    <input
                      type="text"
                      placeholder={v.placeholder}
                      value={variables[v.key] || ""}
                      onChange={(e) =>
                        setVariables((prev) => ({ ...prev, [v.key]: e.target.value }))
                      }
                      onClick={(e) => e.stopPropagation()}
                      className="w-full px-3 py-2 bg-background border border-border rounded-md text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/50 font-mono text-xs"
                    />
                  </div>
                ))}
              </div>
            )}

            {/* Prompt Content */}
            <div className="px-4 pb-3">
              <div className="bg-background/80 border border-border/50 rounded-md p-3 max-h-80 overflow-y-auto">
                <pre className="font-mono text-xs text-foreground/90 whitespace-pre-wrap leading-relaxed">
                  {getFilledPrompt()}
                </pre>
              </div>
            </div>

            {/* Tip */}
            {prompt.tip && (
              <div className="px-4 pb-3">
                <div className="flex items-start gap-2 text-xs text-primary/80 bg-primary/5 border border-primary/10 rounded-md p-2.5">
                  <span className="shrink-0 mt-0.5">💡</span>
                  <span>{prompt.tip}</span>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="px-4 pb-4 flex gap-2">
              <Button
                onClick={(e) => {
                  e.stopPropagation();
                  handleCopy();
                }}
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 text-xs h-9"
              >
                {copied ? (
                  <>
                    <Check className="h-3.5 w-3.5 mr-1.5" />
                    Copié !
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5 mr-1.5" />
                    Copier le prompt
                  </>
                )}
              </Button>
              {onEdit && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit(prompt);
                  }}
                  className="text-xs h-9 border-border text-muted-foreground hover:text-foreground hover:border-primary/40"
                >
                  <SquarePen className="h-3.5 w-3.5 mr-1" />
                  Modifier
                </Button>
              )}
              {isEdited && !isCustom && onReset && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    onReset(prompt.id);
                    toast.success("Prompt restauré à l'original.");
                  }}
                  className="text-xs h-9 border-border text-blue-400 hover:text-blue-300 hover:border-blue-400/40"
                >
                  <RotateCcw className="h-3.5 w-3.5 mr-1" />
                  Original
                </Button>
              )}
              {onDelete && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(prompt.id);
                    toast.success("Prompt supprimé.");
                  }}
                  className="text-xs h-9 border-border text-destructive hover:text-destructive/80 hover:border-destructive/40"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
