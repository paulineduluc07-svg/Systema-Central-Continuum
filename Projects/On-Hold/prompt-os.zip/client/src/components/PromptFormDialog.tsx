/*
 * Design: Command Center — Dark operational dashboard
 * Dialog for creating / editing prompts
 * Amber accent on primary actions, dark inputs
 */
import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Save } from "lucide-react";
import { categories } from "@/lib/prompts";
import type { Prompt, Variable } from "@/lib/prompts";
import { nanoid } from "nanoid";

interface PromptFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (prompt: Prompt) => void;
  editingPrompt?: Prompt | null;
}

const emptyVariable = (): Variable => ({
  key: "",
  label: "",
  placeholder: "",
});

export default function PromptFormDialog({
  open,
  onOpenChange,
  onSave,
  editingPrompt,
}: PromptFormDialogProps) {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState(categories[0].id);
  const [description, setDescription] = useState("");
  const [promptText, setPromptText] = useState("");
  const [tip, setTip] = useState("");
  const [variables, setVariables] = useState<Variable[]>([]);

  const isEditing = !!editingPrompt;

  // Populate form when editing
  useEffect(() => {
    if (editingPrompt) {
      setTitle(editingPrompt.title);
      setCategory(editingPrompt.category);
      setDescription(editingPrompt.description);
      setPromptText(editingPrompt.prompt);
      setTip(editingPrompt.tip || "");
      setVariables(
        editingPrompt.variables.length > 0
          ? editingPrompt.variables
          : []
      );
    } else {
      setTitle("");
      setCategory(categories[0].id);
      setDescription("");
      setPromptText("");
      setTip("");
      setVariables([]);
    }
  }, [editingPrompt, open]);

  const addVariable = () => {
    setVariables((prev) => [...prev, emptyVariable()]);
  };

  const removeVariable = (index: number) => {
    setVariables((prev) => prev.filter((_, i) => i !== index));
  };

  const updateVariable = (index: number, field: keyof Variable, value: string) => {
    setVariables((prev) =>
      prev.map((v, i) => (i === index ? { ...v, [field]: value } : v))
    );
  };

  const handleSave = () => {
    if (!title.trim() || !promptText.trim()) return;

    const prompt: Prompt = {
      id: editingPrompt?.id || `custom-${nanoid(8)}`,
      title: title.trim(),
      category,
      description: description.trim(),
      prompt: promptText.trim(),
      variables: variables.filter((v) => v.key.trim() && v.label.trim()),
      tip: tip.trim() || undefined,
    };

    onSave(prompt);
    onOpenChange(false);
  };

  const inputClass =
    "w-full px-3 py-2 bg-background border border-border rounded-md text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/50 transition-all";

  const labelClass = "block text-xs font-medium text-foreground/70 mb-1.5";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-foreground text-lg">
            {isEditing ? "Modifier le prompt" : "Nouveau prompt"}
          </DialogTitle>
          <DialogDescription className="text-muted-foreground text-xs">
            {isEditing
              ? "Modifiez les champs ci-dessous et sauvegardez."
              : "Remplissez les champs pour créer un nouveau prompt dans votre bibliothèque."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          {/* Title */}
          <div>
            <label className={labelClass}>Titre *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Mon prompt personnalisé"
              className={inputClass}
            />
          </div>

          {/* Category */}
          <div>
            <label className={labelClass}>Catégorie</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className={`${inputClass} cursor-pointer`}
            >
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.title}
                </option>
              ))}
            </select>
          </div>

          {/* Description */}
          <div>
            <label className={labelClass}>Description courte</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Une phrase qui résume ce que fait ce prompt"
              className={inputClass}
            />
          </div>

          {/* Prompt Text */}
          <div>
            <label className={labelClass}>Texte du prompt *</label>
            <textarea
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              placeholder="Écrivez votre prompt ici. Utilisez [NOM_VARIABLE] pour les champs personnalisables."
              rows={8}
              className={`${inputClass} font-mono text-xs leading-relaxed resize-y`}
            />
            <p className="text-[10px] text-muted-foreground/60 mt-1">
              Astuce : utilisez [NOM_VARIABLE] dans le texte pour créer des champs personnalisables.
            </p>
          </div>

          {/* Variables */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className={labelClass + " mb-0"}>
                Variables ({variables.length})
              </label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={addVariable}
                className="text-xs h-7 text-primary hover:text-primary/80"
              >
                <Plus className="h-3 w-3 mr-1" />
                Ajouter
              </Button>
            </div>

            {variables.length > 0 && (
              <div className="space-y-3">
                {variables.map((v, i) => (
                  <div
                    key={i}
                    className="grid grid-cols-[1fr_1fr_1fr_auto] gap-2 items-end bg-background/50 border border-border/50 rounded-md p-2.5"
                  >
                    <div>
                      <label className="text-[10px] text-muted-foreground">
                        Clé
                      </label>
                      <input
                        type="text"
                        value={v.key}
                        onChange={(e) =>
                          updateVariable(i, "key", e.target.value.toUpperCase().replace(/\s/g, "_"))
                        }
                        placeholder="NOM_VARIABLE"
                        className={`${inputClass} text-xs font-mono`}
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-muted-foreground">
                        Label
                      </label>
                      <input
                        type="text"
                        value={v.label}
                        onChange={(e) => updateVariable(i, "label", e.target.value)}
                        placeholder="Nom affiché"
                        className={`${inputClass} text-xs`}
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-muted-foreground">
                        Placeholder
                      </label>
                      <input
                        type="text"
                        value={v.placeholder}
                        onChange={(e) =>
                          updateVariable(i, "placeholder", e.target.value)
                        }
                        placeholder="Ex: votre texte ici"
                        className={`${inputClass} text-xs`}
                      />
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeVariable(i)}
                      className="h-8 w-8 text-destructive hover:text-destructive/80 shrink-0"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Tip */}
          <div>
            <label className={labelClass}>
              Conseil d'utilisation (optionnel)
            </label>
            <input
              type="text"
              value={tip}
              onChange={(e) => setTip(e.target.value)}
              placeholder="Ex: Utilisez-le le dimanche matin pour planifier la semaine"
              className={inputClass}
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-border">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onOpenChange(false)}
              className="text-xs text-muted-foreground"
            >
              Annuler
            </Button>
            <Button
              size="sm"
              onClick={handleSave}
              disabled={!title.trim() || !promptText.trim()}
              className="text-xs bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Save className="h-3.5 w-3.5 mr-1.5" />
              {isEditing ? "Sauvegarder" : "Créer le prompt"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
