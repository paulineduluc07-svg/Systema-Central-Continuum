export interface Prompt {
  id: string;
  title: string;
  category: string;
  description: string;
  prompt: string;
  variables: Variable[];
  tip?: string;
}

export interface Variable {
  key: string;
  label: string;
  placeholder: string;
}

export interface Category {
  id: string;
  title: string;
  icon: string;
  color: string;
  count: number;
  image: string;
}

export const categories: Category[] = [
  {
    id: "productivite",
    title: "Productivité & Organisation",
    icon: "Zap",
    color: "text-amber-400",
    count: 6,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663280949099/UsaNEuiJ3CuHmSfQHWpq33/cat-productivity-YAibPwsoPxmdhQfF3sS5XC.webp",
  },
  {
    id: "clarte",
    title: "Clarté Mentale & Développement",
    icon: "Compass",
    color: "text-blue-400",
    count: 7,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663280949099/UsaNEuiJ3CuHmSfQHWpq33/cat-clarity-nddyqANDQk4v4GjH2Prbao.webp",
  },
  {
    id: "connaissances",
    title: "Connaissances & Apprentissage",
    icon: "BookOpen",
    color: "text-teal-400",
    count: 3,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663280949099/UsaNEuiJ3CuHmSfQHWpq33/cat-knowledge-Rb4wZxfsHPU2PgTQMkDaoF.webp",
  },
  {
    id: "projets",
    title: "Projets, Finances & Design",
    icon: "Rocket",
    color: "text-orange-400",
    count: 5,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663280949099/UsaNEuiJ3CuHmSfQHWpq33/cat-projects-56kjgjGBJTZWepuQ4U7xxm.webp",
  },
  {
    id: "meta",
    title: "Méta-Prompt",
    icon: "Layers",
    color: "text-purple-400",
    count: 1,
    image: "",
  },
];

export const prompts: Prompt[] = [
  // === PRODUCTIVITÉ ===
  {
    id: "anti-procrastination",
    title: "Protocole Anti-Procrastination",
    category: "productivite",
    description: "Brisez l'inertie en 2 minutes. Pas de motivation, juste un coup de pouce.",
    prompt: `Tâche que j'évite constamment : [TÂCHE_ÉVITÉE]

Ne me laissez pas m'en tirer.

Votre rôle :
- Nommez la vraie raison pour laquelle je suis bloqué (pas l'excuse, mais le véritable obstacle)
- Dénoncez le mensonge que je me raconte
- Donnez-moi une action de 2 minutes qui lance l'élan
- Mettez en place un piège pour que je ne puisse plus me défiler

Règles :
- Pas de conseils génériques du type "divisez-la en petites étapes"
- Pas de discours de motivation
- Traitez-moi comme quelqu'un de capable mais qui stagne

Je n'ai pas besoin de motivation. J'ai besoin d'un coup de pouce.`,
    variables: [
      { key: "TÂCHE_ÉVITÉE", label: "Tâche évitée", placeholder: "Ex: Faire mes impôts, depuis 3 semaines" },
    ],
    tip: "Utilisez-le via commande vocale dès que vous sentez une résistance.",
  },
  {
    id: "anti-fatigue-decisionnelle",
    title: "Anti-Fatigue Décisionnelle",
    category: "productivite",
    description: "Créez des systèmes pour ne plus avoir à choisir chaque jour.",
    prompt: `Créez des systèmes qui réduisent ma charge de prise de décision quotidienne.

Contexte : [CONTEXTE_DÉCISIONS]

Pour chaque domaine identifié, proposez :
1. Une règle automatique simple
2. Un template ou routine prédéfinie
3. Un déclencheur "si X alors Y" que je peux appliquer sans réfléchir`,
    variables: [
      { key: "CONTEXTE_DÉCISIONS", label: "Domaines surchargés", placeholder: "Ex: repas, vêtements, routines du matin" },
    ],
    tip: "Idéal pour automatiser repas, tenues et routines matinales.",
  },
  {
    id: "organisateur-taches",
    title: "Organisateur de Tâches",
    category: "productivite",
    description: "Auditez vos responsabilités et triez-les par fréquence.",
    prompt: `Auditez mes responsabilités domestiques. Triez-les en tâches quotidiennes, hebdomadaires et mensuelles qui semblent réalisables.

Mes responsabilités actuelles : [RESPONSABILITÉS]`,
    variables: [
      { key: "RESPONSABILITÉS", label: "Responsabilités", placeholder: "Ex: ménage, courses, lessive, factures, enfants..." },
    ],
  },
  {
    id: "sprint-desencombrement",
    title: "Sprint de Désencombrement Numérique",
    category: "productivite",
    description: "Nettoyez téléphone, bureau, inbox et cloud en 3 jours.",
    prompt: `Soyez mon guide de désintoxication numérique. Créez un sprint de 3 jours pour nettoyer mon téléphone, mon bureau, ma boîte de réception et mon stockage cloud. Incluez des systèmes de nommage de fichiers, des filtres de boîte de réception et une liste de contrôle de réinitialisation mensuelle.`,
    variables: [],
  },
  {
    id: "organisateur-fichiers",
    title: "Organisateur de Fichiers Chaotiques",
    category: "productivite",
    description: "Organisez un dossier en désordre avec renommage intelligent.",
    prompt: `Mon dossier [DOSSIER] est un désastre. J'ai besoin que vous passiez en revue chaque fichier de ce dossier et que vous l'organisiez.

Créez des sous-dossiers par catégorie : Documents, Images, Vidéos, Tableurs, Code, Archives et Divers.

Renommez les fichiers qui ont des noms inutiles comme "IMG_3847" ou "Capture d'écran 2025-12-03" en quelque chose de descriptif basé sur le contenu du fichier.

Utilisez le format : AAAA-MM-JJ_nom-descriptif.ext

Créez un fichier journal appelé rapport-nettoyage.md qui montre chaque fichier que vous avez déplacé, son nouveau nom et pourquoi. Signalez les doublons que vous trouvez mais ne les supprimez pas, déplacez-les simplement dans un dossier Doublons pour que je puisse les examiner.`,
    variables: [
      { key: "DOSSIER", label: "Dossier cible", placeholder: "Ex: Téléchargements, Bureau, Documents" },
    ],
    tip: "Associez ce prompt au premier dimanche du mois.",
  },
  {
    id: "optimiseur-stockage",
    title: "Optimiseur de Stockage",
    category: "productivite",
    description: "Libérez de l'espace sans rien casser.",
    prompt: `Analysez mon stockage : [DÉTAILS_STOCKAGE]. Suggérez des fichiers, des caches et des applications que je peux supprimer ou déplacer pour libérer de l'espace sans rien casser.`,
    variables: [
      { key: "DÉTAILS_STOCKAGE", label: "Détails du stockage", placeholder: "Collez ici les détails de votre stockage" },
    ],
  },

  // === CLARTÉ MENTALE ===
  {
    id: "moteur-decision",
    title: "Moteur de Décision Personnel",
    category: "clarte",
    description: "Stratège impitoyable contre la paralysie d'analyse.",
    prompt: `Vous êtes mon stratège de décision impitoyable, avec une tolérance zéro pour la paralysie d'analyse.

Décision : [DÉCISION]

Livrez :
1. Reformulez en options claires (soit/soit ou plusieurs chemins)
2. Matrice de critères pondérés (tableau : critères, poids, scores par option)
3. Pré-mortem pour chaque option ("12 mois plus tard, cela a échoué – que s'est-il passé ?")
4. Minimisation des regrets (à 80 ans, quel choix entraîne le plus de regrets si NON pris ?)
5. 10/10/10 (comment me sentirai-je dans 10 minutes / 10 mois / 10 ans ?)
6. Options cachées que je ne vois pas (combiner, retarder, couvrir, déléguer)
7. Votre verdict final argumenté avec un paragraphe de justification

Soyez direct. Pas d'hésitation. Aidez-moi à décider, pas à délibérer éternellement.`,
    variables: [
      { key: "DÉCISION", label: "Décision à prendre", placeholder: "Ex: Quitter mon emploi pour lancer mon entreprise" },
    ],
    tip: "Parfait pour les choix importants. Dictez le contexte vocalement.",
  },
  {
    id: "structurer-pensee",
    title: "Structurez Ma Pensée Désordonnée",
    category: "clarte",
    description: "Transformez vos notes en vrac en structure claire.",
    prompt: `Voici un remue-méninges de ce que je pense : [NOTES]. Organisez cela en une structure ou un plan clair sans changer ma voix ou mes idées.`,
    variables: [
      { key: "NOTES", label: "Notes ou fragments", placeholder: "Collez vos pensées en vrac ici..." },
    ],
    tip: "Prenez une note vocale, transcrivez-la, passez-la ici.",
  },
  {
    id: "coach-clarte",
    title: "Stratège de Vie & Miroir de Vérité",
    category: "clarte",
    description: "7 questions inconfortables pour découvrir ce que vous voulez vraiment.",
    prompt: `Agissez en tant que mon Stratège de Vie IA, Coach de Clarté et Miroir de Vérité. Votre rôle est de découvrir ce que je veux vraiment dans la vie, pas ce que la société, la famille, l'argent ou l'ego attendent.

1. Posez-moi 7 questions ultra-ciblées, une à la fois, conçues pour être inconfortables, honnêtes et profondément révélatrices.
2. Assurez-vous que chaque question élimine le désir de plaire, la peur, la comparaison et les fausses ambitions.
3. Concevez les questions pour exposer mes vrais désirs, mes frustrations cachées, mes pertes d'énergie, mes regrets et ma définition personnelle de la liberté.
4. Évitez à tout prix les questions génériques, motivantes ou superficielles.
5. Après que j'aie répondu aux 7 questions, analysez en profondeur mes réponses et identifiez les schémas sans édulcorer ou adoucir la vérité.
6. Créez un Plan de Clarté 2026 basé strictement sur mes réponses, et non sur des cadres de succès génériques.
7. Définissez clairement mes 3 Priorités de Vie Principales pour 2026, en expliquant pourquoi chacune est importante et comment chacune s'aligne avec mes valeurs, mon énergie et ma paix à long terme.
8. Identifiez ce que je dois abandonner immédiatement (habitudes, objectifs, croyances, environnements ou relations) qui me maintient silencieusement bloqué.
9. Construisez une feuille de route de clarté et d'action de 30 jours et terminez par un message puissant et émotionnellement chargé qui me semble personnel et me pousse à agir maintenant au lieu de retarder ma vie.`,
    variables: [],
    tip: "Réservez un dimanche après-midi tranquille. Répondez vocalement.",
  },
  {
    id: "therapeute-ombre",
    title: "Thérapeute Liseur d'Esprit (Shadow Work)",
    category: "clarte",
    description: "Décodage des cycles de sabotage et des boucles émotionnelles.",
    prompt: `Vous êtes un thérapeute liseur d'esprit, exposant l'âme, avec une formation avancée en travail de l'ombre, coaching informé sur les traumatismes, intégration somatique, théorie de l'attachement et conception d'identité de haute performance. Vous ne donnez pas de conseils superficiels, vous effectuez une extraction/analyse psychologique spécialisée dans le décodage des cycles de sabotage, des boucles émotionnelles, des traumatismes non résolus, des désirs et potentiels supprimés avec une clarté terrifiante.

Mon sujet d'exploration : [SUJET]`,
    variables: [
      { key: "SUJET", label: "Sujet à explorer", placeholder: "Ex: Pourquoi je sabote mes relations quand ça devient sérieux" },
    ],
  },
  {
    id: "protocole-execution",
    title: "Le Protocole d'Exécution",
    category: "clarte",
    description: "Protocole en 3 étapes : Excavation, Rupture de Schéma, Synthèse.",
    prompt: `Vous êtes un coach de transformation utilisant un protocole en 3 étapes. Ton : perspicace, orienté systèmes, intellectuellement honnête. Commencez la Phase 1 maintenant.

**Étape 1 : L'Excavation (Matin)**
Posez ces questions une par une :
- Quelle est l'insatisfaction sourde et persistante que vous avez appris à tolérer ?
- Quelle vérité sur votre vie serait insupportable à admettre à quelqu'un que vous respectez ?
- La Trajectoire : Si votre vie reste exactement la même pendant 10 ans, décrivez un mardi en détail vivide. Qui a abandonné sur vous ? Quelles opportunités se sont fermées ? Que disent les gens dans votre dos ?
- La Déclaration Anti-Vision : Aidez l'utilisateur à comprimer cela en une phrase viscérale qu'il refuse de laisser sa vie devenir.

**Étape 2 : La Rupture de Schéma (Journée)**
- Cartographie de l'Ego : Catégorisez l'utilisateur dans l'un des 9 stades (Auto-Protecteur, Conformiste, Consciencieux, Stratège, etc.). Expliquez comment leur stade actuel limite leur intelligence.
- Les Interruptions Cybernétiques : Générez 4 rappels personnalisés horodatés (ex: 11h00, 15h15) que l'utilisateur doit programmer sur son téléphone pour briser ses mécanismes de défense "autopilote".

**Étape 3 : La Synthèse du Jeu Vidéo (Soir)**
Construisez un tableau "Carte de Jeu" avec ces 6 composants :
1. La Victoire (Vision) : Le mardi idéal dans 3 ans.
2. Les Enjeux (Anti-Vision) : La vie d'insatisfaction qu'ils fuient.
3. La Mission (Objectif 1 an) : La seule priorité pour briser l'ancien schéma.
4. Le Boss de Fin (Projet 1 mois) : La compétence/l'actif spécifique qu'ils construisent maintenant.
5. Les Quêtes (Leviers quotidiens) : 2-3 actions "basées sur l'identité" à bloquer dans le temps.
6. Les Règles (Contraintes) : Ce qu'ils ne sacrifieront PAS pour atteindre la vision.`,
    variables: [],
    tip: "Protocole intense. Prévoyez 2-3 heures dans un endroit calme.",
  },
  {
    id: "resilience-mentale",
    title: "Constructeur de Résilience Mentale",
    category: "clarte",
    description: "Habitudes pour rester affûté en période d'incertitude.",
    prompt: `Concevez des habitudes qui me maintiennent affûté pendant de longues périodes d'incertitude.

Mon contexte actuel : [CONTEXTE]`,
    variables: [
      { key: "CONTEXTE", label: "Votre situation", placeholder: "Ex: Transition de carrière, incertitude financière depuis 6 mois" },
    ],
  },
  {
    id: "adaptez-cerveau",
    title: "Adaptez-vous à Mon Cerveau",
    category: "clarte",
    description: "Plan d'apprentissage adapté à votre style cognitif.",
    prompt: `J'apprends mieux par [STYLE_APPRENTISSAGE]. Construisez un plan d'apprentissage pour [SUJET] qui correspond à mon style.`,
    variables: [
      { key: "STYLE_APPRENTISSAGE", label: "Style d'apprentissage", placeholder: "Ex: visuels, exemples pratiques, vidéos" },
      { key: "SUJET", label: "Sujet à apprendre", placeholder: "Ex: le marketing digital, la comptabilité" },
    ],
    tip: "Précisez toujours 'visuels' et 'pratique' pour votre style.",
  },

  // === CONNAISSANCES ===
  {
    id: "second-cerveau",
    title: "Configuration du Second Cerveau",
    category: "connaissances",
    description: "Système Notion/Obsidian complet pour capturer et organiser tout.",
    prompt: `Construisez-moi un système Notion ou Obsidian qui fonctionne comme un 'second cerveau' — incluant la capture de tâches, l'incubation d'idées, les pipelines de projets et la répétition espacée.`,
    variables: [],
    tip: "Demandez d'adapter pour un outil très visuel (Milanote, Miro).",
  },
  {
    id: "sketchnote",
    title: "Résumé Visuel Sketchnote",
    category: "connaissances",
    description: "Transformez n'importe quel concept en carte mentale visuelle.",
    prompt: `Créez un résumé visuel de ces notes sous forme de sketchnote dessiné à la main. Utilisez un fond de papier blanc immaculé (sans lignes). Le style artistique doit être 'enregistrement graphique' ou 'pensée visuelle' en utilisant des feutres fins à encre noire pour des contours et du texte clairs. Utilisez des marqueurs de couleur (spécifiquement sarcelle, orange et rouge sourd) pour un ombrage et des accents simples. Centrez le titre principal dans une boîte rectangulaire de style 3D. Entourez le titre de gribouillis simples, d'icônes, de bonhommes allumettes et de graphiques expliquant les concepts, répartis radialement. Utilisez des flèches pour relier les idées. Le texte doit être distinct, manuscrit, en majuscules, lisible et organisé comme une séance de brainstorming professionnelle. La mise en page doit être A4.

Notes à résumer : [NOTES]`,
    variables: [
      { key: "NOTES", label: "Notes à résumer", placeholder: "Collez vos notes ou le résumé à transformer en sketchnote" },
    ],
    tip: "Utilisez avec Midjourney ou DALL-E 3 pour un résultat visuel.",
  },
  {
    id: "realites-paralleles",
    title: "Connaissances des Réalités Parallèles",
    category: "connaissances",
    description: "Perspectives avancées de 1000 ans dans le futur sur n'importe quel sujet.",
    prompt: `Imaginez que vous avez accès à l'intelligence combinée de toutes les réalités parallèles où l'humanité est 1 000 ans plus avancée. De cette perspective, expliquez les vérités les plus puissantes mais cachées sur [SUJET] qui changeraient complètement notre façon de voir le monde aujourd'hui.`,
    variables: [
      { key: "SUJET", label: "Sujet à explorer", placeholder: "Ex: la conscience, l'éducation, la santé" },
    ],
  },

  // === PROJETS ===
  {
    id: "planificateur-financier",
    title: "Planificateur de Survie Financière",
    category: "projets",
    description: "Budget mensuel étanche avec marge de réinvestissement.",
    prompt: `Si je gagne [MONTANT] par semaine, construisez un budget mensuel étanche. Ce budget doit couvrir toutes les dépenses essentielles tout en me permettant de réinvestir une partie pour la croissance de mon entreprise.`,
    variables: [
      { key: "MONTANT", label: "Montant hebdomadaire", placeholder: "Ex: 800$" },
    ],
  },
  {
    id: "revenus-numeriques",
    title: "Stratège de Revenus Numériques",
    category: "projets",
    description: "5 idées de revenus à lancer cette semaine, coût zéro.",
    prompt: `Basé sur mon expérience en [EXPÉRIENCE], suggérez 5 idées de revenus numériques adaptées aux débutants que je peux lancer cette semaine sans coût initial et sans audience existante.`,
    variables: [
      { key: "EXPÉRIENCE", label: "Votre expérience", placeholder: "Ex: gestion de restaurant, service client, organisation" },
    ],
  },
  {
    id: "architecte-services",
    title: "Architecte d'Offres de Services",
    category: "projets",
    description: "Structurez une idée en service freelance complet.",
    prompt: `À partir de la liste ci-dessus, sélectionnez l'idée la plus viable. Structurez-la en un service freelance complet. Détaillez ce qu'il faut vendre, comment le tarifer, le client cible idéal et les meilleures plateformes pour le proposer.

L'idée sélectionnée : [IDÉE]`,
    variables: [
      { key: "IDÉE", label: "Idée à structurer", placeholder: "Ex: Consultation en optimisation de menu pour restaurants" },
    ],
  },
  {
    id: "machine-contenu",
    title: "Machine à Contenu de Marque Personnelle",
    category: "projets",
    description: "Système perpétuel de création de contenu multi-plateforme.",
    prompt: `Activez le Mode Canevas.
Vous êtes mon copilote de contenu à vie. Je téléchargerai ou collerai ma niche, des échantillons de ma voix et mon public cible une seule fois.

Créez un canevas perpétuel appelé "OS de Contenu" avec une magnifique grille de calendrier mensuel.

Chaque jour est une carte avec : Une idée de publication à forte conviction (titre + format + portée prédite), une image héro déjà générée et intégrée, un statut (Non commencé / Brouillon / Publié).

Boutons sur chaque carte :
1. Rédiger la publication LinkedIn complète + diapositives carrousel
2. Rédiger le fil X + images mèmes
3. Rédiger la section newsletter
4. Rédiger le script YouTube + vignette
5. Réutiliser tout pour e-mail + Instagram

Ma niche : [NICHE]
Mon public cible : [PUBLIC]`,
    variables: [
      { key: "NICHE", label: "Votre niche", placeholder: "Ex: productivité pour entrepreneurs" },
      { key: "PUBLIC", label: "Public cible", placeholder: "Ex: freelancers francophones 25-40 ans" },
    ],
  },
  {
    id: "figma-uiux",
    title: "Expert Figma & Maître UI/UX",
    category: "projets",
    description: "Design d'interface complet selon les standards Apple/Google.",
    prompt: `Agissez en tant que Spécialiste des Opérations de Design Figma. Traduisez [DESCRIPTION_DESIGN] en un système complet, prêt pour Figma.

Définissez la hiérarchie des cadres, les systèmes de grille, les contraintes de mise en page et le comportement responsive. Configurez les propriétés d'auto-layout en détail, incluant direction, espacement, rembourrage, alignement et règles de redimensionnement.

Construisez un système de composants évolutif avec variantes et propriétés, et définissez des tokens de design pour les couleurs, la typographie et les effets.

Incluez des flux de prototype avec déclencheurs et animations, ainsi qu'une configuration complète de handoff développeur couvrant les références CSS, les paramètres d'export, les conventions de nommage et les considérations d'accessibilité.`,
    variables: [
      { key: "DESCRIPTION_DESIGN", label: "Description du design", placeholder: "Ex: Application mobile de suivi d'habitudes avec thème sombre" },
    ],
  },

  // === MÉTA ===
  {
    id: "anatomie-prompt",
    title: "L'Anatomie d'un Prompt Claude",
    category: "meta",
    description: "La structure ultime pour créer vos propres prompts sur mesure.",
    prompt: `Je veux [TÂCHE] afin que [CRITÈRES_SUCCÈS].

D'abord, lisez entièrement ces fichiers avant de répondre :
[fichier.md] — [ce qu'il contient]

Voici une référence de ce que je veux accomplir :
[Téléchargez le fichier de référence en markdown, ou collez-le ici]

Voici ce qui fait que cette référence fonctionne :
[Collez votre plan inversé — les schémas, le ton, la structure et les règles que vous avez extraits de la référence. Formatez chacun comme une règle commençant par "Toujours" ou "Jamais".]

BRIEF DE SUCCÈS
Type de sortie + longueur : [Contrat, mémo, rapport, proposition, page d'atterrissage, publication ?]
Réaction du destinataire : [Que devrait-il penser/ressentir/faire après lecture ?]
Ne doit PAS ressembler à : [Ce qu'il faut éviter — IA générique, trop décontracté, formel, jargon ?]
Le succès signifie : [Ils signent ? Ils approuvent ? Ils répondent ? Ils agissent ?]

Mon fichier de contexte contient mes standards, contraintes, pièges et audience. Lisez-le entièrement avant de commencer. Si vous êtes sur le point de briser une de mes règles, arrêtez et dites-le-moi.

NE COMMENCEZ PAS à exécuter. Posez-moi d'abord des questions de clarification pour qu'on affine l'approche ensemble étape par étape.

Avant d'écrire quoi que ce soit, listez les 3 règles de mon fichier de contexte qui comptent le plus pour cette tâche.

Puis donnez-moi votre plan d'exécution (5 étapes maximum).
Ne commencez le travail qu'une fois qu'on est alignés.`,
    variables: [
      { key: "TÂCHE", label: "Tâche à accomplir", placeholder: "Ex: Rédiger une proposition commerciale" },
      { key: "CRITÈRES_SUCCÈS", label: "Critères de succès", placeholder: "Ex: le client signe dans les 48h" },
    ],
    tip: "C'est votre modèle maître. Utilisez-le pour créer de nouveaux prompts.",
  },
];
