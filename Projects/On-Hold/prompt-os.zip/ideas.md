# Brainstorm Design — Prompt-OS

## Contexte
Application web interactive pour naviguer, copier et tester une bibliothèque de prompts personnels. L'utilisateur est visuel, préfère la simplicité et l'efficacité, et veut un outil qui ressemble à un OS personnel plutôt qu'à un simple catalogue.

---

<response>
<text>

## Idée 1 : "Terminal Néon" — Esthétique Cyberpunk / Hacker
**Design Movement :** Cyberpunk minimaliste inspiré des interfaces de terminal et des IDE modernes (Warp, Hyper).

**Core Principles :**
1. L'interface imite un terminal intelligent — fond sombre, texte monospace, curseur clignotant
2. Chaque prompt est une "commande" qu'on peut exécuter
3. La navigation se fait par catégories sous forme d'onglets latéraux façon fichiers système
4. L'interaction est directe : cliquer = copier, double-cliquer = éditer les variables

**Color Philosophy :** Fond noir profond (#0A0A0F) avec accents néon vert (#00FF88) et cyan (#00D4FF). Le vert signifie "prêt à l'action", le cyan signifie "information". Les erreurs en rouge vif.

**Layout Paradigm :** Split-screen vertical. Sidebar gauche = arborescence de catégories (comme un explorateur de fichiers). Zone centrale = le prompt sélectionné avec ses variables éditables. Zone droite optionnelle = aperçu du prompt complété.

**Signature Elements :** Curseur clignotant dans les champs de variables, effet de "typing" lors de l'affichage d'un prompt, bordures en glow néon subtil.

**Interaction Philosophy :** Tout est rapide et direct. Un clic copie. Les variables sont des champs inline éditables. Pas de modales inutiles.

**Animation :** Texte qui apparaît lettre par lettre (typewriter), transitions de slide latéral entre prompts, glow pulse sur les éléments interactifs.

**Typography System :** JetBrains Mono pour le code/prompts, Space Grotesk pour les titres et la navigation.

</text>
<probability>0.07</probability>
</response>

<response>
<text>

## Idée 2 : "Carte de Tarot" — Esthétique Mystique / Carte à Jouer
**Design Movement :** Art Nouveau digital mélangé avec du design de cartes à collectionner (TCG).

**Core Principles :**
1. Chaque prompt est une "carte" avec un visuel, un titre et une description
2. Les catégories sont des "decks" qu'on peut feuilleter
3. L'interface est tactile et ludique — on "pioche" un prompt
4. Le design évoque la puissance et le mystère de chaque prompt

**Color Philosophy :** Fond crème ancien (#F5F0E8) avec dorures (#C9A84C), encre noire profonde (#1A1A2E) et accents bordeaux (#8B1A1A). Le doré = valeur, le bordeaux = intensité.

**Layout Paradigm :** Grille de cartes centrée avec effet de profondeur (cartes empilées). Cliquer sur une carte l'ouvre en plein écran avec le prompt complet et les champs éditables.

**Signature Elements :** Bordures ornementales sur les cartes, icônes symboliques par catégorie (épée pour productivité, œil pour clarté, livre pour apprentissage), effet de flip 3D.

**Interaction Philosophy :** Ludique et engageante. On explore comme un jeu de cartes. Le côté "mystique" rend chaque prompt désirable.

**Animation :** Flip 3D des cartes, parallax subtil sur le fond, shimmer doré sur les bordures au hover.

**Typography System :** Playfair Display pour les titres (élégance), DM Sans pour le corps (lisibilité moderne).

</text>
<probability>0.05</probability>
</response>

<response>
<text>

## Idée 3 : "Command Center" — Esthétique Dashboard Opérationnel
**Design Movement :** Design d'interface de contrôle de mission (NASA/SpaceX) croisé avec le Brutalism digital épuré.

**Core Principles :**
1. L'interface est un tableau de bord opérationnel — chaque prompt est un "module" activable
2. Les catégories sont des sections horizontales avec des indicateurs visuels
3. L'accent est mis sur l'action immédiate : chaque prompt a un bouton "Copier" et "Personnaliser" visible
4. Design utilitaire — pas de décoration inutile, chaque pixel sert

**Color Philosophy :** Fond gris anthracite très sombre (#111116) avec blanc cassé (#E8E6E3) pour le texte. Accents en ambre chaud (#F59E0B) pour les actions et en bleu acier (#64748B) pour les éléments secondaires. L'ambre = action urgente, le bleu = navigation calme.

**Layout Paradigm :** Navigation horizontale par catégories en haut (tabs). En dessous, grille asymétrique de cartes de prompts avec tailles variables selon l'importance. Sidebar rétractable pour les filtres et la recherche.

**Signature Elements :** Badges de catégorie avec icônes géométriques, barre de recherche proéminente façon "command palette" (Cmd+K), compteur de prompts par catégorie, indicateur de variables à remplir.

**Interaction Philosophy :** Efficace et sans friction. La barre de recherche est le point d'entrée principal. Les variables sont éditables inline avec des placeholders clairs. Copier en un clic avec feedback visuel.

**Animation :** Transitions fluides entre catégories (slide horizontal), apparition progressive des cartes (stagger), flash ambre sur le bouton copier pour confirmer l'action, micro-animation sur les badges.

**Typography System :** Instrument Sans pour les titres (géométrique, moderne, autoritaire), Inter pour le corps (neutre, lisible), JetBrains Mono pour le contenu des prompts (distinction claire entre UI et contenu).

</text>
<probability>0.08</probability>
</response>

---

## Choix retenu : Idée 3 — "Command Center"

Raison : C'est l'approche la plus alignée avec le profil de l'utilisateur (efficacité, action rapide, pas de décoration inutile). Le design utilitaire type "dashboard opérationnel" correspond à sa mentalité de gestionnaire orientée résultats. La barre de recherche façon command palette et les actions en un clic répondent à son besoin de minimiser l'interaction avec la technologie.
